<?php

namespace Webkul\Activity\Contracts;

interface Activity {}
