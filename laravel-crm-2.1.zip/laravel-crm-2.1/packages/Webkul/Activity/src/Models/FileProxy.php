<?php

namespace Webkul\Activity\Models;

use Konekt\Concord\Proxies\ModelProxy;

class FileProxy extends ModelProxy {}
