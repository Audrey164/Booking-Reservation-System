<div class="row grid grid-cols-3 items-center gap-2.5 border-b px-4 py-2.5 dark:border-gray-800">
    <div class="shimmer h-[26px] w-6"></div>

    <div class="shimmer h-[17px] w-[100px]"></div>

    <div class="shimmer h-[17px] w-[100px] place-self-end"></div>
</div>