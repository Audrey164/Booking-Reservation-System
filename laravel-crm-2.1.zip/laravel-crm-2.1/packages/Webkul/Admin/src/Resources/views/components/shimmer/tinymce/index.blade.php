<div {{ $attributes->merge(['class' => 'shimmer block bg-neutral-100']) }}>

</div>