<div class="row grid grid-cols-3 items-center gap-2.5 border-b px-4 py-4 text-gray-600 dark:border-gray-800 dark:text-gray-300">
    <div class="shimmer mb-0.5 h-6 w-6"></div>

    <div class="shimmer h-[17px] w-[100px]"></div>

    <div class="flex gap-2.5 place-self-end">
        <div class="shimmer my-1 h-7 w-7 p-1.5"></div>

        <div class="shimmer my-1 h-7 w-7 p-1.5"></div>

        <div class="shimmer my-1 h-7 w-7 p-1.5"></div>
    </div>
</div>