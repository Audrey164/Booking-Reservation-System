<?php

namespace Webkul\Admin\Helpers\Reporting;

class Activity extends AbstractReporting {}
